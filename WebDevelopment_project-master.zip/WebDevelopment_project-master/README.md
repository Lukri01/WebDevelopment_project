# WebDevelopment_project
#### Room booking web application
On the website, it is possible to create accounts and login. The users can choose whether they are landlords or renters. Landlords can put available rooms and add a description and pictures. Renters can view the available rooms, contact the landlord and leave textual reviews as well as ratings. 

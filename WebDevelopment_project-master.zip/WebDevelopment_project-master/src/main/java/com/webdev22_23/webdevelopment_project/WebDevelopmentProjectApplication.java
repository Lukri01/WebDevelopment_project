
package com.webdev22_23.webdevelopment_project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebDevelopmentProjectApplication {

    public static void main(String[] args) {
        SpringApplication.run(WebDevelopmentProjectApplication.class, args);
    }

}

package com.webdev22_23.webdevelopment_project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebDevelopmentProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}

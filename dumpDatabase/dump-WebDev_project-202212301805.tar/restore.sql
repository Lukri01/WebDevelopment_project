--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.5
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "WebDev_project";
--
-- Name: WebDev_project; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "WebDev_project" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'German_Austria.1252';


ALTER DATABASE "WebDev_project" OWNER TO postgres;

\connect "WebDev_project"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: picture; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.picture (
    picture_id uuid NOT NULL,
    data character varying NOT NULL
);


ALTER TABLE public.picture OWNER TO postgres;

--
-- Name: review; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.review (
    review_id uuid NOT NULL,
    title character varying NOT NULL,
    body character varying NOT NULL,
    rating numeric(3,1) NOT NULL,
    written_by character varying NOT NULL,
    refered_to uuid NOT NULL,
    CONSTRAINT review_check CHECK (((rating >= (0)::numeric) AND (rating <= (10)::numeric)))
);


ALTER TABLE public.review OWNER TO postgres;

--
-- Name: room; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.room (
    room_id uuid NOT NULL,
    price numeric(7,2) NOT NULL,
    title character varying NOT NULL,
    body character varying NOT NULL,
    location character varying NOT NULL,
    landlord character varying NOT NULL,
    renter character varying NOT NULL,
    CONSTRAINT room_check CHECK ((price > (0)::numeric))
);


ALTER TABLE public.room OWNER TO postgres;

--
-- Name: room_picture; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.room_picture (
    room_picture_id uuid NOT NULL,
    room_id uuid NOT NULL,
    picture_id uuid NOT NULL
);


ALTER TABLE public.room_picture OWNER TO postgres;

--
-- Name: user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."user" (
    username character varying NOT NULL,
    password character varying NOT NULL,
    email character varying NOT NULL,
    first_name character varying NOT NULL,
    last_name character varying NOT NULL,
    user_type character varying NOT NULL
);


ALTER TABLE public."user" OWNER TO postgres;

--
-- Data for Name: picture; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.picture (picture_id, data) FROM stdin;
\.
COPY public.picture (picture_id, data) FROM '$$PATH$$/3339.dat';

--
-- Data for Name: review; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.review (review_id, title, body, rating, written_by, refered_to) FROM stdin;
\.
COPY public.review (review_id, title, body, rating, written_by, refered_to) FROM '$$PATH$$/3338.dat';

--
-- Data for Name: room; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.room (room_id, price, title, body, location, landlord, renter) FROM stdin;
\.
COPY public.room (room_id, price, title, body, location, landlord, renter) FROM '$$PATH$$/3337.dat';

--
-- Data for Name: room_picture; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.room_picture (room_picture_id, room_id, picture_id) FROM stdin;
\.
COPY public.room_picture (room_picture_id, room_id, picture_id) FROM '$$PATH$$/3340.dat';

--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."user" (username, password, email, first_name, last_name, user_type) FROM stdin;
\.
COPY public."user" (username, password, email, first_name, last_name, user_type) FROM '$$PATH$$/3336.dat';

--
-- Name: picture picture_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.picture
    ADD CONSTRAINT picture_pk PRIMARY KEY (picture_id);


--
-- Name: review review_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review
    ADD CONSTRAINT review_pk PRIMARY KEY (review_id);


--
-- Name: room_picture room_picture_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.room_picture
    ADD CONSTRAINT room_picture_pk PRIMARY KEY (room_picture_id);


--
-- Name: room room_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.room
    ADD CONSTRAINT room_pk PRIMARY KEY (room_id);


--
-- Name: user user_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pk PRIMARY KEY (username);


--
-- Name: review review_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review
    ADD CONSTRAINT review_fk FOREIGN KEY (written_by) REFERENCES public."user"(username) ON DELETE SET NULL;


--
-- Name: review review_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review
    ADD CONSTRAINT review_fk_1 FOREIGN KEY (refered_to) REFERENCES public.room(room_id) ON DELETE SET NULL;


--
-- Name: room room_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.room
    ADD CONSTRAINT room_fk_1 FOREIGN KEY (landlord) REFERENCES public."user"(username) ON DELETE SET NULL;


--
-- Name: room room_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.room
    ADD CONSTRAINT room_fk_2 FOREIGN KEY (renter) REFERENCES public."user"(username) ON DELETE SET NULL;


--
-- Name: room_picture room_picture_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.room_picture
    ADD CONSTRAINT room_picture_fk FOREIGN KEY (room_id) REFERENCES public.room(room_id) ON DELETE SET NULL;


--
-- Name: room_picture room_picture_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.room_picture
    ADD CONSTRAINT room_picture_fk_1 FOREIGN KEY (picture_id) REFERENCES public.picture(picture_id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

